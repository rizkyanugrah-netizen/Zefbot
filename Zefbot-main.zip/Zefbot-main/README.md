Welcome
--------|
![](https://media.tenor.com/iVCiM9W7cvYAAAAd/welcome.gif)

# Zefbot
Script termux auto view video tiktok terbaru !

<details open><summary><code>Perintah Script?</code></summary>

```php
$ git clone https://github.com/Sxp-ID/Zefbot
$ cd Zefbot
$ make install
$ ./main

Atau bisa juga run script nya dg ketik perintah
$ make run
```
</details>

## Full tutorialnya?
- Link video v1 (old) <code><a href="https://youtu.be/0spDpbw8cN4?si=S-LBf3e_whj1NZXW">klik disini</a></code>
- Link video v2 (new) <code><a href="https://youtu.be/vgSMlCN9iE4?si=CZpjuksa3BADEtvv">klik disini</a></code>
- Subs yt admin <code><a href="https://youtube.com/@freetutorialofficial">FREE TUTORIAL</a></code>
<div align="center">

### Jgn lupa kasih star masbro !
</div>
